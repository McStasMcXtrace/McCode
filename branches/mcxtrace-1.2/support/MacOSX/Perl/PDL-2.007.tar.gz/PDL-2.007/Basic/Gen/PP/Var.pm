
package C::Var;

# Get one from C::Type;

sub alloccode {
}

sub copycode {
}

sub freecode {
}
