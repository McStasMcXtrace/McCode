/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.9.1/configure --enable-languages=c++,fortran";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "core2" } };
