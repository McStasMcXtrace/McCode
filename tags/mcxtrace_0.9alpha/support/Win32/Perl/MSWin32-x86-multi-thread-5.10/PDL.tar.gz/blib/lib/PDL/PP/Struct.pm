# Just container for many C::Types

package C::StructType;

package C::StructObj;
