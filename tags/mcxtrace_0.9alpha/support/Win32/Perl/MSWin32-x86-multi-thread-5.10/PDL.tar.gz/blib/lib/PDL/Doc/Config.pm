# automatically built from Config.pm.PL
# don't modify, all changes will be lost !!!!
package PDL::Doc::Config;

$PDL::Doc::pager = 'more /e';
$PDL::Doc::pager = $ENV{PAGER} if defined $ENV{PAGER};
$PDL::Doc::DefaultFile = 'c:\perl510_M\man\man1';

1;

