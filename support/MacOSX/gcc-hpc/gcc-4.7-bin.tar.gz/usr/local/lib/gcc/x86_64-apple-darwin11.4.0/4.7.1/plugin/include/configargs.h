/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.7.1/configure --enable-languages=fortran";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "core2" } };
